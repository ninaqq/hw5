#include <stdio.h>
#include <stdlib.h>

int main(int argc, const char * argv[]) {


	int bubble[100], n, tmp;
	scanf_s("%d", &n);

	for (int i = 0; i < n; i++)
		scanf_s("%d", &bubble[i]);
		printf("\n");

	for (int i = 0; i < n - 1; i++) 
	{
		for (int j = 0; j < n - 1; j++) 
		{
			if (bubble[j] > bubble[j + 1])
			{
				tmp = bubble[j];
				bubble[j] = bubble[j + 1];
				bubble[j + 1] = tmp;
			}	

		}			
		for (int i = 0; i < n; i++)
			printf("%d ", bubble[i]);
			printf("\n");
	}


	return 0;
}
